/// @file logo.c
/// @brief
/// @copyright (c) 2014-2022 This file is distributed under the MIT License.
/// See LICENSE.md for details.

#include <stdio.h>
#include <time.h>

int main(int argc, char **argv)
{
    printf("                   __  __                  _      ___    ____  \n");
    printf("                  |  \\/  |   ___   _ __   | |_   / _ \\  / ___| \n");
    printf("                  | |\\/| |  / _ \\ | '_ \\  | __| | | | | \\___ \\ \n");
    printf("                  | |  | | |  __/ | | | | | |_  | |_| |  ___) |\n");
    printf("                  |_|  |_|  \\___| |_| |_|  \\__|  \\___/  |____/ \n");
    return 0;
}
